// Tower Defense Game - SFML 3.0.2 Compatible
// Fixed: Map selection now correctly starts the game.

#include <SFML/Graphics.hpp>
#include <vector>
#include <memory>
#include <algorithm>
#include <iostream>
#include <cmath>
#include <string>
#include <sstream>

using namespace std;

// ======================================================
// Forward declarations
// ======================================================
class Enemy;
class Tower;

// ======================================================
// Global Constants
// ======================================================
const float WINDOW_WIDTH = 1200.f;
const float WINDOW_HEIGHT = 768.f;
const int UI_PANEL_WIDTH = 250;

// ======================================================
// Map Configuration
// ======================================================
struct MapConfig {
    string name;
    vector<sf::Vector2f> waypoints;
    sf::Color backgroundColor;
    sf::Color pathColor;
    int difficulty;
    float goldMultiplier;
    string description;

    MapConfig(string n, vector<sf::Vector2f> points, sf::Color bg, sf::Color path, int diff, float goldMult, string desc)
        : name(n), waypoints(points), backgroundColor(bg), pathColor(path),
        difficulty(diff), goldMultiplier(goldMult), description(desc) {
    }
};

// Pre-defined maps - redesigned with complex spiral-like paths
const vector<MapConfig> AVAILABLE_MAPS = {
    // Map 1: Forest Spiral (complex covering entire area)
    MapConfig("Forest Spiral",
        {
            {50.f, 50.f}, {200.f, 50.f}, {200.f, 150.f}, {350.f, 150.f}, {350.f, 50.f},
            {500.f, 50.f}, {500.f, 200.f}, {650.f, 200.f}, {650.f, 100.f}, {800.f, 100.f},
            {800.f, 250.f}, {650.f, 250.f}, {650.f, 350.f}, {800.f, 350.f}, {800.f, 450.f},
            {650.f, 450.f}, {650.f, 550.f}, {800.f, 550.f}, {800.f, 650.f}, {500.f, 650.f},
            {500.f, 500.f}, {350.f, 500.f}, {350.f, 650.f}, {200.f, 650.f}, {200.f, 550.f},
            {50.f, 550.f}, {50.f, 400.f}, {200.f, 400.f}, {200.f, 300.f}, {50.f, 300.f}
        },
        sf::Color(20, 50, 20), sf::Color(60, 40, 20), 1, 1.0f,
        "A twisting spiral through dense woods.\nPerfect for learning path defense."),

        // Map 2: Desert Maze (tight zigzag)
        MapConfig("Desert Maze",
            {
                {50.f, 100.f}, {150.f, 100.f}, {150.f, 250.f}, {300.f, 250.f}, {300.f, 100.f},
                {450.f, 100.f}, {450.f, 300.f}, {600.f, 300.f}, {600.f, 150.f}, {750.f, 150.f},
                {750.f, 350.f}, {600.f, 350.f}, {600.f, 500.f}, {750.f, 500.f}, {750.f, 650.f},
                {500.f, 650.f}, {500.f, 550.f}, {350.f, 550.f}, {350.f, 650.f}, {200.f, 650.f},
                {200.f, 500.f}, {350.f, 500.f}, {350.f, 350.f}, {200.f, 350.f}, {200.f, 200.f},
                {50.f, 200.f}
            },
            sf::Color(80, 60, 30), sf::Color(120, 100, 50), 2, 1.2f,
            "A labyrinthine canyon path.\nMedium difficulty."),

        // Map 3: Mountain Labyrinth (extreme spiral)
        MapConfig("Mountain Labyrinth",
            {
                {50.f, 100.f}, {250.f, 100.f}, {250.f, 250.f}, {100.f, 250.f}, {100.f, 400.f},
                {250.f, 400.f}, {250.f, 550.f}, {100.f, 550.f}, {100.f, 700.f}, {400.f, 700.f},
                {400.f, 550.f}, {550.f, 550.f}, {550.f, 700.f}, {700.f, 700.f}, {700.f, 500.f},
                {550.f, 500.f}, {550.f, 350.f}, {700.f, 350.f}, {700.f, 200.f}, {550.f, 200.f},
                {550.f, 100.f}, {700.f, 100.f}, {700.f, 50.f}, {400.f, 50.f}, {400.f, 200.f},
                {250.f, 200.f}
            },
            sf::Color(40, 40, 60), sf::Color(80, 70, 90), 3, 1.5f,
            "A deadly spiral carved into the mountain.\nHard difficulty."),

        // Map 4: Ice Vortex (full coverage spiral)
        MapConfig("Ice Vortex",
            {
                {50.f, 50.f}, {300.f, 50.f}, {300.f, 200.f}, {100.f, 200.f}, {100.f, 350.f},
                {300.f, 350.f}, {300.f, 500.f}, {100.f, 500.f}, {100.f, 650.f}, {250.f, 650.f},
                {250.f, 550.f}, {450.f, 550.f}, {450.f, 700.f}, {600.f, 700.f}, {600.f, 500.f},
                {500.f, 500.f}, {500.f, 350.f}, {650.f, 350.f}, {650.f, 200.f}, {500.f, 200.f},
                {500.f, 50.f}, {700.f, 50.f}, {700.f, 150.f}, {850.f, 150.f}, {850.f, 350.f},
                {750.f, 350.f}, {750.f, 550.f}, {850.f, 550.f}, {850.f, 700.f}, {950.f, 700.f}
            },
            sf::Color(30, 50, 70), sf::Color(100, 130, 150), 4, 1.8f,
            "A frozen vortex demanding perfect placement.\nExpert difficulty.")
};

// ======================================================
// Helper Functions
// ======================================================
float distance(const sf::Vector2f& a, const sf::Vector2f& b) {
    float dx = a.x - b.x;
    float dy = a.y - b.y;
    return sqrt(dx * dx + dy * dy);
}

// ======================================================
// Base Entity Class (Abstract)
// ======================================================
class Entity {
public:
    virtual ~Entity() = default;
    virtual void update(float dt) = 0;
    virtual void render(sf::RenderWindow& window) = 0;
};

// ======================================================
// Enemy Base Class (Abstract)
// ======================================================
class Enemy : public Entity {
protected:
    sf::Vector2f position;
    float speed;
    float hp;
    float maxHp;
    sf::RectangleShape shape;
    int currentWaypoint;
    float reward;
    string enemyType;
    float slowTimer;
    float originalSpeed;
    vector<sf::Vector2f> waypoints;

public:
    Enemy(sf::Vector2f start, float spd, float health, float rewardAmount, const string& type, const vector<sf::Vector2f>& waypointsList)
        : position(start), speed(spd), hp(health), maxHp(health),
        currentWaypoint(1), reward(rewardAmount), enemyType(type),
        slowTimer(0.f), originalSpeed(spd), waypoints(waypointsList) {
        shape.setSize(sf::Vector2f(24.f, 24.f));
        shape.setPosition(position);
    }

    virtual ~Enemy() = default;

    void takeDamage(float dmg) {
        hp -= dmg;
        if (hp < 0.f) hp = 0.f;
    }

    void heal(float amount) {
        hp = min(maxHp, hp + amount);
    }

    bool isDead() const { return hp <= 0.f; }
    sf::Vector2f getPosition() const { return position; }
    float getHP() const { return hp; }
    float getMaxHP() const { return maxHp; }
    float getReward() const { return reward; }
    string getType() const { return enemyType; }

    void applySlow(float slowAmount, float duration) {
        if (slowTimer <= 0.f) {
            originalSpeed = speed;
            speed = max(20.f, speed * slowAmount);
        }
        slowTimer = duration;
    }

    virtual void update(float dt) override {
        if (slowTimer > 0.f) {
            slowTimer -= dt;
            if (slowTimer <= 0.f) {
                speed = originalSpeed;
            }
        }

        if (currentWaypoint < (int)waypoints.size()) {
            sf::Vector2f target = waypoints[currentWaypoint];
            sf::Vector2f direction = target - position;
            float dist = sqrt(direction.x * direction.x + direction.y * direction.y);

            if (dist < 5.f) {
                currentWaypoint++;
            }
            else {
                direction /= dist;
                position += direction * speed * dt;
            }
        }

        shape.setPosition(position);
    }

    // HP bar is drawn on top of the enemy shape – clearly visible
    virtual void render(sf::RenderWindow& window) override {
        window.draw(shape);

        sf::RectangleShape bg(sf::Vector2f(28.f, 5.f));
        bg.setFillColor(sf::Color(50, 50, 50));
        bg.setPosition(position + sf::Vector2f(-2.f, -10.f));

        sf::RectangleShape bar(sf::Vector2f(28.f * (hp / maxHp), 5.f));

        if (hp / maxHp > 0.6f)
            bar.setFillColor(sf::Color::Green);
        else if (hp / maxHp > 0.3f)
            bar.setFillColor(sf::Color::Yellow);
        else
            bar.setFillColor(sf::Color::Red);

        bar.setPosition(position + sf::Vector2f(-2.f, -10.f));

        window.draw(bg);
        window.draw(bar);
    }

    virtual bool hasReachedEnd() const {
        return currentWaypoint >= (int)waypoints.size() - 1;
    }
};

// ======================================================
// Enemy Types
// ======================================================
class BasicEnemy : public Enemy {
public:
    BasicEnemy(sf::Vector2f start, const vector<sf::Vector2f>& waypoints)
        : Enemy(start, 80.f, 100.f, 50.f, "Basic", waypoints) {
        shape.setFillColor(sf::Color::Red);
    }
};

class FastEnemy : public Enemy {
public:
    FastEnemy(sf::Vector2f start, const vector<sf::Vector2f>& waypoints)
        : Enemy(start, 180.f, 45.f, 40.f, "Fast", waypoints) {
        shape.setFillColor(sf::Color::Yellow);
    }
};

class TankEnemy : public Enemy {
public:
    TankEnemy(sf::Vector2f start, const vector<sf::Vector2f>& waypoints)
        : Enemy(start, 40.f, 300.f, 80.f, "Tank", waypoints) {
        shape.setFillColor(sf::Color(139, 69, 19));
    }
};

class FlyingEnemy : public Enemy {
private:
    sf::Vector2f direction;
public:
    FlyingEnemy(sf::Vector2f start, const vector<sf::Vector2f>& waypoints)
        : Enemy(start, 120.f, 70.f, 60.f, "Flying", waypoints) {
        shape.setFillColor(sf::Color::Magenta);
        direction = sf::Vector2f(1.f, 0.5f);
        float len = sqrt(direction.x * direction.x + direction.y * direction.y);
        direction /= len;
    }

    void update(float dt) override {
        position += direction * speed * dt;
        shape.setPosition(position);
    }

    // Flying enemies leave the map and cost lives
    bool hasReachedEnd() const override {
        float playAreaRight = WINDOW_WIDTH - UI_PANEL_WIDTH;
        if (position.x > playAreaRight + 20.f || position.x < -20.f ||
            position.y > WINDOW_HEIGHT + 20.f || position.y < -20.f) {
            return true;
        }
        return false;
    }

    // HP bar for flying enemy (diamond shape)
    void render(sf::RenderWindow& window) override {
        sf::ConvexShape diamond;
        diamond.setPointCount(4);
        diamond.setPoint(0, sf::Vector2f(0, -12));
        diamond.setPoint(1, sf::Vector2f(12, 0));
        diamond.setPoint(2, sf::Vector2f(0, 12));
        diamond.setPoint(3, sf::Vector2f(-12, 0));
        diamond.setFillColor(sf::Color::Magenta);
        diamond.setPosition(position);
        window.draw(diamond);

        sf::RectangleShape bg(sf::Vector2f(24.f, 4.f));
        bg.setFillColor(sf::Color(50, 50, 50));
        bg.setPosition(position + sf::Vector2f(-12.f, -14.f));

        sf::RectangleShape bar(sf::Vector2f(24.f * (hp / maxHp), 4.f));
        bar.setFillColor(sf::Color::Green);
        bar.setPosition(position + sf::Vector2f(-12.f, -14.f));

        window.draw(bg);
        window.draw(bar);
    }
};

class HealingEnemy : public Enemy {
private:
    float healCooldown;
    float healAmount;
public:
    HealingEnemy(sf::Vector2f start, const vector<sf::Vector2f>& waypoints)
        : Enemy(start, 65.f, 120.f, 75.f, "Healer", waypoints),
        healCooldown(0.f), healAmount(15.f) {
        shape.setFillColor(sf::Color(0, 255, 128));
    }

    void update(float dt) override {
        Enemy::update(dt);
        if (healCooldown > 0.f) {
            healCooldown -= dt;
        }
    }

    bool canHeal() const { return healCooldown <= 0.f; }
    void resetHealCooldown() { healCooldown = 3.f; }
    float getHealAmount() const { return healAmount; }
};

// Boss enemy
class BossEnemy : public Enemy {
public:
    BossEnemy(sf::Vector2f start, const vector<sf::Vector2f>& waypoints)
        : Enemy(start, 30.f, 800.f, 150.f, "Boss", waypoints) {
        shape.setSize(sf::Vector2f(32.f, 32.f));
        shape.setFillColor(sf::Color(128, 0, 0));
    }
};

// ======================================================
// Tower Base Class (Abstract)  (nerfed base stats used by derived)
// ======================================================
class Tower : public Entity {
protected:
    sf::Vector2f position;
    float range;
    float damage;
    float attackCooldown;
    float cooldownTimer;
    sf::CircleShape rangeCircle;
    sf::RectangleShape shape;
    int upgradeLevel;
    float baseDamage;
    float baseRange;
    int upgradeCost;
    string towerType;

public:
    Tower(sf::Vector2f pos, float rng, float dmg, float attackRate, const string& type, int upCost = 100)
        : position(pos), range(rng), damage(dmg), attackCooldown(attackRate),
        cooldownTimer(0.f), upgradeLevel(0), baseDamage(dmg), baseRange(rng),
        upgradeCost(upCost), towerType(type) {
        shape.setSize(sf::Vector2f(24.f, 24.f));
        shape.setOrigin(sf::Vector2f(12.f, 12.f));
        shape.setPosition(position);

        rangeCircle.setRadius(range);
        rangeCircle.setFillColor(sf::Color(100, 100, 255, 20));
        rangeCircle.setOutlineColor(sf::Color(100, 100, 255, 100));
        rangeCircle.setOutlineThickness(1.f);
        rangeCircle.setOrigin(sf::Vector2f(range, range));
        rangeCircle.setPosition(position);
    }

    virtual ~Tower() = default;

    bool isInRange(const Enemy& enemy) {
        return distance(position, enemy.getPosition()) <= range;
    }

    sf::Vector2f getPosition() const { return position; }
    int getUpgradeLevel() const { return upgradeLevel; }
    int getUpgradeCost() const { return upgradeCost; }
    string getType() const { return towerType; }
    float getDamage() const { return damage; }
    float getRange() const { return range; }

    bool canUpgrade() const { return upgradeLevel < 3; }

    void upgrade() {
        if (upgradeLevel < 3) {
            upgradeLevel++;
            damage = baseDamage * (1.f + upgradeLevel * 0.5f);
            range = baseRange * (1.f + upgradeLevel * 0.15f);
            upgradeCost = 100 * (upgradeLevel + 1);

            rangeCircle.setRadius(range);
            rangeCircle.setOrigin(sf::Vector2f(range, range));

            sf::Color newColor = shape.getFillColor();
            newColor.r = min(255, newColor.r + 40);
            newColor.g = min(255, newColor.g + 40);
            shape.setFillColor(newColor);
        }
    }

    virtual void attack(vector<unique_ptr<Enemy>>& enemies, vector<sf::Vector2f>& effects) = 0;

    void update(float dt) override {
        if (cooldownTimer > 0.f) {
            cooldownTimer -= dt;
        }
    }

    void render(sf::RenderWindow& window) override {
        window.draw(rangeCircle);
        window.draw(shape);

        sf::CircleShape levelIndicator(6.f);
        levelIndicator.setFillColor(sf::Color::White);
        levelIndicator.setPosition(position + sf::Vector2f(9.f, -9.f));
        window.draw(levelIndicator);
    }

    void setRangeVisible(bool visible) {
        if (visible) {
            rangeCircle.setFillColor(sf::Color(100, 100, 255, 50));
            rangeCircle.setOutlineColor(sf::Color(100, 100, 255, 200));
        }
        else {
            rangeCircle.setFillColor(sf::Color(100, 100, 255, 20));
            rangeCircle.setOutlineColor(sf::Color(100, 100, 255, 100));
        }
    }
};

// ======================================================
// Tower Types (all nerfed)
// ======================================================
class CannonTower : public Tower {
public:
    CannonTower(sf::Vector2f pos) : Tower(pos, 45.f, 30.f, 1.6f, "Cannon", 120) {
        shape.setFillColor(sf::Color(0, 100, 200));
    }

    void attack(vector<unique_ptr<Enemy>>& enemies, vector<sf::Vector2f>& effects) override {
        if (cooldownTimer > 0.f) return;
        for (auto& enemy : enemies) {
            if (!enemy->isDead() && isInRange(*enemy)) {
                enemy->takeDamage(damage);
                cooldownTimer = attackCooldown;
                effects.push_back(position);
                break;
            }
        }
    }
};

class SniperTower : public Tower {
public:
    SniperTower(sf::Vector2f pos) : Tower(pos, 65.f, 50.f, 2.5f, "Sniper", 150) {
        shape.setFillColor(sf::Color(80, 80, 80));
    }

    void attack(vector<unique_ptr<Enemy>>& enemies, vector<sf::Vector2f>& effects) override {
        if (cooldownTimer > 0.f) return;
        Enemy* target = nullptr;
        for (auto& enemy : enemies) {
            if (!enemy->isDead() && isInRange(*enemy)) {
                target = enemy.get();
                break;
            }
        }
        if (target) {
            target->takeDamage(damage);
            cooldownTimer = attackCooldown;
            effects.push_back(position);
        }
    }
};

class MachineGunTower : public Tower {
public:
    MachineGunTower(sf::Vector2f pos) : Tower(pos, 30.f, 8.f, 0.4f, "Machine Gun", 100) {
        shape.setFillColor(sf::Color(0, 150, 0));
    }

    void attack(vector<unique_ptr<Enemy>>& enemies, vector<sf::Vector2f>& effects) override {
        if (cooldownTimer > 0.f) return;
        for (auto& enemy : enemies) {
            if (!enemy->isDead() && isInRange(*enemy)) {
                enemy->takeDamage(damage);
                cooldownTimer = attackCooldown;
                effects.push_back(position);
                break;
            }
        }
    }
};

class SlowTower : public Tower {
private:
    float slowAmount;
    float slowDuration;
public:
    SlowTower(sf::Vector2f pos) : Tower(pos, 40.f, 0.f, 2.0f, "Slow", 130),
        slowAmount(0.5f), slowDuration(2.5f) {
        shape.setFillColor(sf::Color(100, 0, 150));
    }

    void attack(vector<unique_ptr<Enemy>>& enemies, vector<sf::Vector2f>& effects) override {
        if (cooldownTimer > 0.f) return;
        bool applied = false;
        for (auto& enemy : enemies) {
            if (!enemy->isDead() && isInRange(*enemy)) {
                enemy->applySlow(slowAmount, slowDuration);
                applied = true;
            }
        }
        if (applied) {
            cooldownTimer = attackCooldown;
            effects.push_back(position);
        }
    }
};

class TeslaTower : public Tower {
private:
    int chainCount;
public:
    TeslaTower(sf::Vector2f pos) : Tower(pos, 40.f, 20.f, 1.4f, "Tesla", 140),
        chainCount(3) {
        shape.setFillColor(sf::Color::Yellow);
    }

    void attack(vector<unique_ptr<Enemy>>& enemies, vector<sf::Vector2f>& effects) override {
        if (cooldownTimer > 0.f) return;
        vector<Enemy*> targets;
        for (auto& enemy : enemies) {
            if (!enemy->isDead() && isInRange(*enemy)) {
                targets.push_back(enemy.get());
            }
        }
        if (!targets.empty()) {
            for (int i = 0; i < min(chainCount, (int)targets.size()); i++) {
                targets[i]->takeDamage(damage / (i + 1));
            }
            cooldownTimer = attackCooldown;
            effects.push_back(position);
        }
    }
};

// ======================================================
// Wave System (5 waves)
// ======================================================
struct Wave {
    int waveNumber;
    vector<pair<string, int>> enemies;
    float spawnDelay;

    Wave(int num, float goldMultiplier) : waveNumber(num), spawnDelay(1.0f) {
        switch (num) {
        case 1: enemies = { {"Basic", 6} }; break;
        case 2: enemies = { {"Basic", 5}, {"Fast", 4} }; break;
        case 3: enemies = { {"Tank", 3}, {"Healer", 2}, {"Fast", 5} }; break;
        case 4: enemies = { {"Flying", 5}, {"Healer", 3}, {"Tank", 3}, {"Boss", 1} }; break;
        case 5: enemies = { {"Boss", 2}, {"Flying", 7}, {"Healer", 3}, {"Tank", 4}, {"Basic", 5} }; break;
        default: enemies = { {"Basic", 3} }; break;
        }
    }
};

// ======================================================
// Game Manager (Main Game Logic)
// ======================================================
class GameManager {
private:
    int lives;
    int gold;
    int currentWave;
    vector<Wave> waves;
    bool gameOver;
    bool gameWin;
    MapConfig currentMap;

    vector<unique_ptr<Enemy>> enemies;
    vector<unique_ptr<Tower>> towers;
    vector<sf::Vector2f> attackEffects;

    float spawnTimer;
    int enemiesToSpawnQueue;
    vector<pair<string, int>> currentWaveEnemies;
    int enemyIndex;

    unique_ptr<sf::Font> font;
    unique_ptr<sf::Text> livesText;
    unique_ptr<sf::Text> goldText;
    unique_ptr<sf::Text> waveText;
    unique_ptr<sf::Text> gameOverText;
    unique_ptr<sf::Text> winText;
    unique_ptr<sf::Text> restartText;
    unique_ptr<sf::Text> mapNameText;
    unique_ptr<sf::Text> difficultyText;

    unique_ptr<sf::Text> shopHeaderText;
    vector<unique_ptr<sf::Text>> towerShopTexts;
    unique_ptr<sf::Text> shopControlsText;
    unique_ptr<sf::Text> placementText;

    bool placingTower;
    int selectedTowerType;
    vector<int> towerCosts;
    vector<string> towerNames;
    vector<sf::Color> towerColors;

    vector<sf::RectangleShape> pathRectangles;
    sf::RectangleShape mapBackground;
    sf::RectangleShape startPoint;
    sf::RectangleShape endPoint;
    sf::RectangleShape uiPanel;

    float healerHealTimer;

public:
    GameManager(const MapConfig& map) :
        lives(5),
        gold(2000),
        currentWave(0),
        gameOver(false),
        gameWin(false),
        currentMap(map),
        spawnTimer(0.f),
        enemiesToSpawnQueue(0),
        enemyIndex(0),
        placingTower(false),
        selectedTowerType(0),
        healerHealTimer(0.f) {

        for (int i = 1; i <= 5; i++) {
            waves.emplace_back(i, map.goldMultiplier);
        }

        towerCosts = { 150, 200, 120, 180, 220 };
        towerNames = { "Cannon", "Sniper", "Machine Gun", "Slow", "Tesla" };
        towerColors = {
            sf::Color(0, 100, 200),
            sf::Color(80, 80, 80),
            sf::Color(0, 150, 0),
            sf::Color(100, 0, 150),
            sf::Color(255, 255, 0)
        };

        font = make_unique<sf::Font>();
        bool fontLoaded = font->openFromFile("arial.ttf");
        if (!fontLoaded) {
            fontLoaded = font->openFromFile("C:/Windows/Fonts/arial.ttf");
            if (!fontLoaded) {
                cerr << "Error: Could not load font!" << endl;
            }
        }

        initUI();
        initMap();
        startNextWave();
    }

    void initUI() {
        uiPanel.setSize(sf::Vector2f(UI_PANEL_WIDTH, WINDOW_HEIGHT));
        uiPanel.setFillColor(sf::Color(20, 20, 30, 230));
        uiPanel.setPosition(sf::Vector2f(WINDOW_WIDTH - UI_PANEL_WIDTH, 0.f));

        livesText = make_unique<sf::Text>(*font, "LIVES: 5", 24);
        livesText->setFillColor(sf::Color::Red);
        livesText->setPosition(sf::Vector2f(WINDOW_WIDTH - UI_PANEL_WIDTH + 20.f, 20.f));

        goldText = make_unique<sf::Text>(*font, "GOLD: 2000", 24);
        goldText->setFillColor(sf::Color::Yellow);
        goldText->setPosition(sf::Vector2f(WINDOW_WIDTH - UI_PANEL_WIDTH + 20.f, 60.f));

        waveText = make_unique<sf::Text>(*font, "WAVE: 0/5", 24);
        waveText->setFillColor(sf::Color::Cyan);
        waveText->setPosition(sf::Vector2f(WINDOW_WIDTH - UI_PANEL_WIDTH + 20.f, 100.f));

        mapNameText = make_unique<sf::Text>(*font, "MAP: " + currentMap.name, 18);
        mapNameText->setFillColor(sf::Color(150, 150, 150));
        mapNameText->setPosition(sf::Vector2f(WINDOW_WIDTH - UI_PANEL_WIDTH + 20.f, 150.f));

        string diffText = "DIFFICULTY: ";
        if (currentMap.difficulty == 1) diffText += "EASY";
        else if (currentMap.difficulty == 2) diffText += "MEDIUM";
        else if (currentMap.difficulty == 3) diffText += "HARD";
        else diffText += "EXPERT";
        difficultyText = make_unique<sf::Text>(*font, diffText, 18);
        difficultyText->setFillColor(sf::Color(200, 200, 100));
        difficultyText->setPosition(sf::Vector2f(WINDOW_WIDTH - UI_PANEL_WIDTH + 20.f, 180.f));

        shopHeaderText = make_unique<sf::Text>(*font, "=== TOWER SHOP ===", 18);
        shopHeaderText->setFillColor(sf::Color::White);
        shopHeaderText->setPosition(sf::Vector2f(WINDOW_WIDTH - UI_PANEL_WIDTH + 20.f, 230.f));

        float yOffset = 260.f;
        for (int i = 0; i < 5; ++i) {
            auto txt = make_unique<sf::Text>(*font, "", 16);
            txt->setFillColor(towerColors[i]);
            txt->setPosition(sf::Vector2f(WINDOW_WIDTH - UI_PANEL_WIDTH + 20.f, yOffset));
            towerShopTexts.push_back(move(txt));
            yOffset += 30.f;
        }

        shopControlsText = make_unique<sf::Text>(*font, "=== CONTROLS ===\n"
            "Left-click: Place tower\n"
            "Right-click: Upgrade tower\n"
            "P: Pause game\n"
            "ESC: Cancel placement", 14);
        shopControlsText->setFillColor(sf::Color(180, 180, 180));
        shopControlsText->setPosition(sf::Vector2f(WINDOW_WIDTH - UI_PANEL_WIDTH + 20.f, yOffset + 10.f));

        placementText = make_unique<sf::Text>(*font, "", 18);
        placementText->setFillColor(sf::Color::Cyan);
        placementText->setPosition(sf::Vector2f(WINDOW_WIDTH - UI_PANEL_WIDTH + 20.f, 230.f));

        gameOverText = make_unique<sf::Text>(*font, "GAME OVER!", 48);
        gameOverText->setFillColor(sf::Color::Red);
        gameOverText->setPosition(sf::Vector2f(WINDOW_WIDTH / 2 - 100.f, WINDOW_HEIGHT / 2 - 80.f));

        winText = make_unique<sf::Text>(*font, "VICTORY!", 48);
        winText->setFillColor(sf::Color::Green);
        winText->setPosition(sf::Vector2f(WINDOW_WIDTH / 2 - 80.f, WINDOW_HEIGHT / 2 - 80.f));

        restartText = make_unique<sf::Text>(*font, "Press R to restart, M for menu", 20);
        restartText->setFillColor(sf::Color::White);
        restartText->setPosition(sf::Vector2f(WINDOW_WIDTH / 2 - 140.f, WINDOW_HEIGHT / 2));
    }

    void initMap() {
        mapBackground.setSize(sf::Vector2f(WINDOW_WIDTH - UI_PANEL_WIDTH, WINDOW_HEIGHT));
        mapBackground.setFillColor(currentMap.backgroundColor);
        mapBackground.setPosition(sf::Vector2f(0.f, 0.f));

        pathRectangles.clear();
        for (int i = 0; i < (int)currentMap.waypoints.size() - 1; i++) {
            sf::Vector2f start = currentMap.waypoints[i];
            sf::Vector2f end = currentMap.waypoints[i + 1];

            sf::Vector2f direction = end - start;
            float length = sqrt(direction.x * direction.x + direction.y * direction.y);
            float angleRad = atan2(direction.y, direction.x);
            float angleDeg = angleRad * 180 / 3.14159f;

            sf::RectangleShape segment(sf::Vector2f(length, 30.f));
            segment.setFillColor(currentMap.pathColor);
            segment.setOrigin(sf::Vector2f(0.f, 15.f));
            segment.setPosition(start);
            segment.setRotation(sf::degrees(angleDeg));

            pathRectangles.push_back(segment);
        }

        startPoint.setSize(sf::Vector2f(30.f, 30.f));
        startPoint.setFillColor(sf::Color::Green);
        startPoint.setPosition(currentMap.waypoints[0] - sf::Vector2f(15.f, 15.f));

        endPoint.setSize(sf::Vector2f(30.f, 30.f));
        endPoint.setFillColor(sf::Color::Red);
        endPoint.setPosition(currentMap.waypoints.back() - sf::Vector2f(15.f, 15.f));
    }

    void startNextWave() {
        if (currentWave >= (int)waves.size()) {
            gameWin = true;
            return;
        }
        currentWaveEnemies = waves[currentWave].enemies;
        enemyIndex = 0;
        enemiesToSpawnQueue = 0;
        spawnTimer = 0.f;
        for (auto& e : currentWaveEnemies) {
            enemiesToSpawnQueue += e.second;
        }
        currentWave++;
    }

    void spawnEnemy() {
        if (enemiesToSpawnQueue <= 0) return;
        if (enemyIndex >= (int)currentWaveEnemies.size()) return;

        auto& enemyTypeData = currentWaveEnemies[enemyIndex];
        string type = enemyTypeData.first;
        int& count = enemyTypeData.second;

        if (count <= 0) {
            enemyIndex++;
            if (enemyIndex >= (int)currentWaveEnemies.size()) return;
            type = currentWaveEnemies[enemyIndex].first;
            count = currentWaveEnemies[enemyIndex].second;
        }

        sf::Vector2f startPos = currentMap.waypoints[0];
        unique_ptr<Enemy> enemy;

        if (type == "Basic") enemy = make_unique<BasicEnemy>(startPos, currentMap.waypoints);
        else if (type == "Fast") enemy = make_unique<FastEnemy>(startPos, currentMap.waypoints);
        else if (type == "Tank") enemy = make_unique<TankEnemy>(startPos, currentMap.waypoints);
        else if (type == "Flying") enemy = make_unique<FlyingEnemy>(startPos, currentMap.waypoints);
        else if (type == "Healer") enemy = make_unique<HealingEnemy>(startPos, currentMap.waypoints);
        else if (type == "Boss") enemy = make_unique<BossEnemy>(startPos, currentMap.waypoints);
        else enemy = make_unique<BasicEnemy>(startPos, currentMap.waypoints);

        enemies.push_back(move(enemy));
        count--;
        enemiesToSpawnQueue--;
    }

    void updateHealingEnemies(float dt) {
        healerHealTimer += dt;
        if (healerHealTimer >= 2.f) {
            healerHealTimer = 0.f;
            for (auto& healer : enemies) {
                if (healer->getType() == "Healer" && !healer->isDead()) {
                    HealingEnemy* healerPtr = dynamic_cast<HealingEnemy*>(healer.get());
                    if (healerPtr && healerPtr->canHeal()) {
                        for (auto& other : enemies) {
                            if (!other->isDead() && other.get() != healer.get()) {
                                if (distance(healer->getPosition(), other->getPosition()) < 80.f) {
                                    other->heal(healerPtr->getHealAmount());
                                }
                            }
                        }
                        healerPtr->resetHealCooldown();
                    }
                }
            }
        }
    }

    void update(float dt) {
        if (gameOver || gameWin) return;

        if (enemiesToSpawnQueue > 0) {
            spawnTimer += dt;
            if (spawnTimer >= 1.2f) {
                spawnTimer = 0.f;
                spawnEnemy();
            }
        }

        updateHealingEnemies(dt);

        for (auto it = enemies.begin(); it != enemies.end();) {
            (*it)->update(dt);
            if ((*it)->hasReachedEnd()) {
                lives--;
                it = enemies.erase(it);
            }
            else {
                ++it;
            }
        }

        for (auto& tower : towers) {
            tower->update(dt);
            tower->attack(enemies, attackEffects);
        }

        enemies.erase(
            remove_if(enemies.begin(), enemies.end(),
                [this](const unique_ptr<Enemy>& enemy) {
                    if (enemy->isDead()) {
                        gold += static_cast<int>(enemy->getReward() * currentMap.goldMultiplier);
                        return true;
                    }
                    return false;
                }),
            enemies.end()
        );

        if (enemies.empty() && enemiesToSpawnQueue == 0 && currentWave < (int)waves.size()) {
            startNextWave();
        }
        else if (enemies.empty() && enemiesToSpawnQueue == 0 && currentWave >= (int)waves.size() && !gameWin) {
            gameWin = true;
        }

        if (lives <= 0) {
            gameOver = true;
        }

        attackEffects.clear();
        updateUI();
    }

    void updateUI() {
        livesText->setString("LIVES: " + to_string(lives));
        goldText->setString("GOLD: " + to_string(gold));

        if (currentWave <= (int)waves.size()) {
            waveText->setString("WAVE: " + to_string(currentWave) + "/" + to_string(waves.size()));
        }
        else if (!gameWin) {
            waveText->setString("WAVE: " + to_string(waves.size()) + "/" + to_string(waves.size()));
        }
        else {
            waveText->setString("WAVE: COMPLETE!");
        }

        bool showShop = !placingTower;
        shopHeaderText->setString(showShop ? "=== TOWER SHOP ===" : "");
        shopHeaderText->setFillColor(sf::Color::White);

        for (int i = 0; i < 5; ++i) {
            if (showShop) {
                stringstream ss;
                ss << (i + 1) << ". " << towerNames[i] << " - " << towerCosts[i] << "g";
                towerShopTexts[i]->setString(ss.str());
                towerShopTexts[i]->setFillColor(towerColors[i]);
            }
            else {
                towerShopTexts[i]->setString("");
            }
        }

        shopControlsText->setString(showShop ? "=== CONTROLS ===\n"
            "Left-click: Place tower\n"
            "Right-click: Upgrade tower\n"
            "P: Pause game\n"
            "ESC: Cancel placement" : "");

        if (placingTower) {
            stringstream ss;
            ss << ">> PLACING TOWER <<\n\n"
                << "TYPE: " << towerNames[selectedTowerType] << "\n"
                << "COST: " << towerCosts[selectedTowerType] << " gold\n\n"
                << "Press 1-5 to change\n"
                << "Right-click to cancel\n"
                << "Press P to pause";
            placementText->setString(ss.str());
        }
        else {
            placementText->setString("");
        }
    }

    void handleMouseClick(sf::Vector2i mousePos, bool isRightClick) {
        if (gameOver || gameWin) return;
        sf::Vector2f worldPos(static_cast<float>(mousePos.x), static_cast<float>(mousePos.y));
        if (worldPos.x > WINDOW_WIDTH - UI_PANEL_WIDTH) return;

        if (isRightClick) {
            if (placingTower) {
                placingTower = false;
            }
            else {
                for (auto& tower : towers) {
                    if (distance(tower->getPosition(), worldPos) < 20.f) {
                        if (tower->canUpgrade() && gold >= tower->getUpgradeCost()) {
                            tower->upgrade();
                            gold -= tower->getUpgradeCost();
                        }
                        break;
                    }
                }
            }
        }
        else {
            if (placingTower) {
                bool onPath = false;
                for (auto& waypoint : currentMap.waypoints) {
                    if (distance(worldPos, waypoint) < 40.f) {
                        onPath = true;
                        break;
                    }
                }
                bool towerExists = false;
                for (auto& tower : towers) {
                    if (distance(tower->getPosition(), worldPos) < 20.f) {
                        towerExists = true;
                        break;
                    }
                }
                if (!onPath && !towerExists && gold >= towerCosts[selectedTowerType]) {
                    unique_ptr<Tower> newTower;
                    switch (selectedTowerType) {
                    case 0: newTower = make_unique<CannonTower>(worldPos); break;
                    case 1: newTower = make_unique<SniperTower>(worldPos); break;
                    case 2: newTower = make_unique<MachineGunTower>(worldPos); break;
                    case 3: newTower = make_unique<SlowTower>(worldPos); break;
                    case 4: newTower = make_unique<TeslaTower>(worldPos); break;
                    default: newTower = make_unique<CannonTower>(worldPos); break;
                    }
                    towers.push_back(move(newTower));
                    gold -= towerCosts[selectedTowerType];
                }
                placingTower = false;
            }
            else {
                placingTower = true;
                for (auto& tower : towers) {
                    tower->setRangeVisible(true);
                }
            }
        }
    }

    void handleKeyPress(sf::Keyboard::Key key) {
        if (key == sf::Keyboard::Key::Num1) selectedTowerType = 0;
        if (key == sf::Keyboard::Key::Num2) selectedTowerType = 1;
        if (key == sf::Keyboard::Key::Num3) selectedTowerType = 2;
        if (key == sf::Keyboard::Key::Num4) selectedTowerType = 3;
        if (key == sf::Keyboard::Key::Num5) selectedTowerType = 4;
        if (key == sf::Keyboard::Key::Escape) placingTower = false;

        if (gameOver || gameWin) {
            if (key == sf::Keyboard::Key::R) {
                resetGame();
            }
        }
    }

    void resetGame() {
        lives = 5;
        gold = 2000;
        currentWave = 0;
        gameOver = false;
        gameWin = false;
        enemies.clear();
        towers.clear();
        placingTower = false;
        attackEffects.clear();
        startNextWave();
    }

    void render(sf::RenderWindow& window) {
        window.draw(mapBackground);
        for (auto& segment : pathRectangles) {
            window.draw(segment);
        }
        window.draw(startPoint);
        window.draw(endPoint);

        for (auto& tower : towers) {
            tower->render(window);
        }
        for (auto& enemy : enemies) {
            enemy->render(window);
        }
        for (auto& effect : attackEffects) {
            sf::CircleShape effectCircle(8.f);
            effectCircle.setFillColor(sf::Color(255, 255, 100, 200));
            effectCircle.setPosition(effect);
            window.draw(effectCircle);
        }

        window.draw(uiPanel);
        window.draw(*livesText);
        window.draw(*goldText);
        window.draw(*waveText);
        window.draw(*mapNameText);
        window.draw(*difficultyText);

        window.draw(*shopHeaderText);
        for (auto& txt : towerShopTexts) {
            window.draw(*txt);
        }
        window.draw(*shopControlsText);
        window.draw(*placementText);

        if (gameOver || gameWin) {
            sf::RectangleShape overlay(sf::Vector2f(WINDOW_WIDTH, WINDOW_HEIGHT));
            overlay.setFillColor(sf::Color(0, 0, 0, 180));
            window.draw(overlay);
        }

        if (gameOver) {
            window.draw(*gameOverText);
            window.draw(*restartText);
        }
        else if (gameWin) {
            window.draw(*winText);
            window.draw(*restartText);
        }

        if (placingTower && !gameOver && !gameWin) {
            sf::CircleShape preview(12.f);
            preview.setFillColor(sf::Color(100, 100, 255, 100));
            preview.setOutlineColor(sf::Color::Cyan);
            preview.setOutlineThickness(2.f);
            sf::Vector2i mousePos = sf::Mouse::getPosition(window);
            if (mousePos.x < WINDOW_WIDTH - UI_PANEL_WIDTH) {
                preview.setPosition(sf::Vector2f(static_cast<float>(mousePos.x) - 12.f,
                    static_cast<float>(mousePos.y) - 12.f));
                window.draw(preview);
            }
        }
    }

    bool isGameOver() const { return gameOver; }
    bool isGameWin() const { return gameWin; }
};

// ======================================================
// Main Menu Class – polished aesthetics, aligned text
// ======================================================
class MainMenu {
private:
    sf::Font font;
    vector<unique_ptr<sf::Text>> mapOptions;
    vector<unique_ptr<sf::Text>> mapDescriptions;
    int selectedMapIndex;
    sf::RectangleShape background;
    sf::RectangleShape titleBar;
    unique_ptr<sf::Text> titleText;
    unique_ptr<sf::Text> subtitleText;
    unique_ptr<sf::Text> startPrompt;
    unique_ptr<sf::Text> quitText;
    unique_ptr<sf::Text> mapHeaderText;
    unique_ptr<sf::Text> mapInstructionText;
    vector<sf::RectangleShape> decorativeShapes;
    bool showMaps;
    vector<MapConfig> maps;

public:
    MainMenu() : selectedMapIndex(0), showMaps(false) {
        maps = AVAILABLE_MAPS;

        bool fontLoaded = font.openFromFile("arial.ttf");
        if (!fontLoaded) {
            fontLoaded = font.openFromFile("C:/Windows/Fonts/arial.ttf");
            if (!fontLoaded) {
                cerr << "Error: Could not load menu font!" << endl;
            }
        }

        background.setSize(sf::Vector2f(WINDOW_WIDTH, WINDOW_HEIGHT));
        background.setFillColor(sf::Color(15, 15, 30));

        titleBar.setSize(sf::Vector2f(WINDOW_WIDTH, 140.f));
        titleBar.setFillColor(sf::Color(30, 30, 50));

        sf::RectangleShape line1(sf::Vector2f(WINDOW_WIDTH, 4.f));
        line1.setPosition({ 0.f, 140.f });
        line1.setFillColor(sf::Color(200, 150, 50));
        decorativeShapes.push_back(line1);

        sf::RectangleShape line2(sf::Vector2f(WINDOW_WIDTH, 2.f));
        line2.setPosition({ 0.f, 146.f });
        line2.setFillColor(sf::Color(100, 80, 30));
        decorativeShapes.push_back(line2);

        titleText = make_unique<sf::Text>(font, "TOWER DEFENSE", 72);
        titleText->setFillColor(sf::Color(255, 220, 50));
        titleText->setOutlineColor(sf::Color(150, 100, 20));
        titleText->setOutlineThickness(2.f);
        titleText->setPosition(sf::Vector2f(WINDOW_WIDTH / 2 - 220.f, 20.f));

        subtitleText = make_unique<sf::Text>(font, "Defend your realm against endless waves", 28);
        subtitleText->setFillColor(sf::Color(200, 200, 200));
        subtitleText->setPosition(sf::Vector2f(WINDOW_WIDTH / 2 - 260.f, 100.f));

        startPrompt = make_unique<sf::Text>(font, "Press ENTER to Select Map", 38);
        startPrompt->setFillColor(sf::Color(255, 255, 255));
        startPrompt->setOutlineColor(sf::Color(50, 50, 50));
        startPrompt->setOutlineThickness(1.f);
        startPrompt->setPosition(sf::Vector2f(WINDOW_WIDTH / 2 - 240.f, WINDOW_HEIGHT / 2 - 60.f));

        quitText = make_unique<sf::Text>(font, "Press ESC to Quit", 28);
        quitText->setFillColor(sf::Color(220, 220, 220));
        quitText->setPosition(sf::Vector2f(WINDOW_WIDTH / 2 - 140.f, WINDOW_HEIGHT / 2 + 10.f));

        mapHeaderText = make_unique<sf::Text>(font, "SELECT YOUR MAP", 36);
        mapHeaderText->setFillColor(sf::Color::White);
        mapHeaderText->setPosition(sf::Vector2f(WINDOW_WIDTH / 2 - 180.f, 180.f));

        mapInstructionText = make_unique<sf::Text>(font, "Arrow keys to navigate   |   ENTER to start   |   ESC to return", 20);
        mapInstructionText->setFillColor(sf::Color(180, 180, 180));
        mapInstructionText->setPosition(sf::Vector2f(WINDOW_WIDTH / 2 - 350.f, 240.f));

        float yPos = 310.f;
        for (int i = 0; i < (int)maps.size(); i++) {
            string mapName = maps[i].name;
            string difficulty = (maps[i].difficulty == 1) ? "EASY" :
                (maps[i].difficulty == 2) ? "MEDIUM" :
                (maps[i].difficulty == 3) ? "HARD" : "EXPERT";

            auto mapText = make_unique<sf::Text>(font, mapName + "  [" + difficulty + "]", 32);
            mapText->setPosition(sf::Vector2f(200.f, yPos));
            mapText->setFillColor(i == 0 ? sf::Color::Yellow : sf::Color::White);
            mapOptions.push_back(move(mapText));

            auto descText = make_unique<sf::Text>(font, maps[i].description, 18);
            descText->setPosition(sf::Vector2f(200.f, yPos + 40.f));
            descText->setFillColor(sf::Color(160, 160, 160));
            mapDescriptions.push_back(move(descText));

            yPos += 100.f;
        }
    }

    // Only used for Up/Down/Escape when maps are shown, and for the initial Enter to show maps
    void handleKeyPress(sf::Keyboard::Key key) {
        if (!showMaps) {
            if (key == sf::Keyboard::Key::Enter) {
                showMaps = true;
            }
        }
        else {
            if (key == sf::Keyboard::Key::Escape) {
                showMaps = false;
            }
            else if (key == sf::Keyboard::Key::Up) {
                selectedMapIndex = (selectedMapIndex - 1 + (int)maps.size()) % maps.size();
                updateSelection();
            }
            else if (key == sf::Keyboard::Key::Down) {
                selectedMapIndex = (selectedMapIndex + 1) % maps.size();
                updateSelection();
            }
            // Enter key is handled in main loop to start the game
        }
    }

    void updateSelection() {
        for (int i = 0; i < (int)mapOptions.size(); i++) {
            mapOptions[i]->setFillColor(i == selectedMapIndex ? sf::Color::Yellow : sf::Color::White);
        }
    }

    MapConfig getSelectedMap() const {
        return maps[selectedMapIndex];
    }

    void render(sf::RenderWindow& window) {
        window.draw(background);
        window.draw(titleBar);
        for (auto& shape : decorativeShapes) {
            window.draw(shape);
        }
        window.draw(*titleText);
        window.draw(*subtitleText);

        if (!showMaps) {
            window.draw(*startPrompt);
            window.draw(*quitText);
        }
        else {
            window.draw(*mapHeaderText);
            window.draw(*mapInstructionText);
            for (auto& text : mapOptions) {
                window.draw(*text);
            }
            for (auto& text : mapDescriptions) {
                window.draw(*text);
            }
        }
    }

    void resetSelection() {
        selectedMapIndex = 0;
        showMaps = false;
        updateSelection();
    }

    bool isShowingMaps() const { return showMaps; }
};

// ======================================================
// Game State Enum
// ======================================================
enum GameState {
    MENU,
    PLAYING,
    PAUSED
};

// ======================================================
// Operator Overloading Example
// ======================================================
struct Vector2D {
    float x, y;

    Vector2D operator+(const Vector2D& other) const {
        return { x + other.x, y + other.y };
    }

    Vector2D operator-(const Vector2D& other) const {
        return { x - other.x, y - other.y };
    }

    Vector2D operator*(float scalar) const {
        return { x * scalar, y * scalar };
    }

    bool operator==(const Vector2D& other) const {
        return x == other.x && y == other.y;
    }
};

// ======================================================
// Main Function – fixed map start logic
// ======================================================
int main() {
    sf::RenderWindow window(sf::VideoMode(sf::Vector2u((unsigned int)WINDOW_WIDTH, (unsigned int)WINDOW_HEIGHT)),
        "Tower Defense - OOP Project");
    window.setFramerateLimit(60);

    MainMenu menu;
    GameState gameState = MENU;
    sf::Clock clock;
    unique_ptr<GameManager> game = nullptr;

    Vector2D v1 = { 10.f, 20.f };
    Vector2D v2 = { 5.f, 10.f };
    Vector2D v3 = v1 + v2;
    Vector2D v4 = v1 * 2.f;
    cout << "Operator Overloading Demo: (10,20)+(5,10)=(" << v3.x << "," << v3.y << ")" << endl;
    cout << "Vector multiplication (10,20)*2 = (" << v4.x << "," << v4.y << ")" << endl;
    cout << "\n=== TOWER DEFENSE GAME ===" << endl;
    cout << "Start screen - press Enter to see maps, ESC to quit" << endl;

    while (window.isOpen()) {
        while (const std::optional event = window.pollEvent()) {
            if (event->is<sf::Event::Closed>()) {
                window.close();
            }

            if (const auto* keyPressed = event->getIf<sf::Event::KeyPressed>()) {
                if (gameState == MENU) {
                    // ESC handling
                    if (keyPressed->code == sf::Keyboard::Key::Escape) {
                        if (!menu.isShowingMaps()) {
                            window.close();
                        }
                        else {
                            menu.handleKeyPress(sf::Keyboard::Key::Escape); // return to title
                        }
                    }
                    // Map selection state
                    else if (menu.isShowingMaps()) {
                        if (keyPressed->code == sf::Keyboard::Key::Up ||
                            keyPressed->code == sf::Keyboard::Key::Down) {
                            menu.handleKeyPress(keyPressed->code);
                        }
                        else if (keyPressed->code == sf::Keyboard::Key::Enter) {
                            // Start the game with the selected map
                            MapConfig selectedMap = menu.getSelectedMap();
                            game = make_unique<GameManager>(selectedMap);
                            gameState = PLAYING;
                            cout << "Starting game on map: " << selectedMap.name << endl;
                        }
                    }
                    // Title screen (maps not shown)
                    else {
                        if (keyPressed->code == sf::Keyboard::Key::Enter) {
                            menu.handleKeyPress(keyPressed->code); // show maps
                        }
                    }
                }
                else if (gameState == PLAYING) {
                    if (game && (game->isGameOver() || game->isGameWin())) {
                        if (keyPressed->code == sf::Keyboard::Key::R) {
                            game->handleKeyPress(sf::Keyboard::Key::R);
                        }
                        else if (keyPressed->code == sf::Keyboard::Key::M) {
                            gameState = MENU;
                            menu.resetSelection();
                            game.reset();
                            cout << "Returned to Main Menu" << endl;
                        }
                    }
                    else {
                        if (keyPressed->code == sf::Keyboard::Key::P) {
                            gameState = PAUSED;
                            cout << "Game Paused" << endl;
                        }
                        else if (game) {
                            game->handleKeyPress(keyPressed->code);
                        }
                    }
                }
                else if (gameState == PAUSED) {
                    if (keyPressed->code == sf::Keyboard::Key::P) {
                        gameState = PLAYING;
                        cout << "Game Resumed" << endl;
                    }
                    else if (keyPressed->code == sf::Keyboard::Key::M) {
                        gameState = MENU;
                        menu.resetSelection();
                        game.reset();
                        cout << "Returned to Main Menu" << endl;
                    }
                }
            }

            // Mouse handling
            if (gameState == PLAYING && game && !game->isGameOver() && !game->isGameWin()) {
                if (const auto* mouseBtn = event->getIf<sf::Event::MouseButtonPressed>()) {
                    if (mouseBtn->button == sf::Mouse::Button::Left) {
                        game->handleMouseClick(sf::Mouse::getPosition(window), false);
                    }
                    else if (mouseBtn->button == sf::Mouse::Button::Right) {
                        game->handleMouseClick(sf::Mouse::getPosition(window), true);
                    }
                }
            }
        }

        float dt = clock.restart().asSeconds();
        if (dt > 0.033f) dt = 0.033f;

        if (gameState == PLAYING && game) {
            game->update(dt);
        }

        window.clear(sf::Color(20, 20, 30));

        if (gameState == MENU) {
            menu.render(window);
        }
        else if (gameState == PLAYING && game) {
            game->render(window);
        }
        else if (gameState == PAUSED && game) {
            game->render(window);
            sf::RectangleShape overlay(sf::Vector2f(WINDOW_WIDTH, WINDOW_HEIGHT));
            overlay.setFillColor(sf::Color(0, 0, 0, 180));
            window.draw(overlay);

            sf::Font pauseFont;
            bool loaded = pauseFont.openFromFile("arial.ttf");
            if (!loaded) {
                loaded = pauseFont.openFromFile("C:/Windows/Fonts/arial.ttf");
                if (!loaded) {
                    cerr << "Could not load pause font!" << endl;
                }
            }

            sf::Text pauseText(pauseFont, "PAUSED", 48);
            sf::Text resumeText(pauseFont, "Press P to resume\nPress M for Main Menu", 24);

            pauseText.setFillColor(sf::Color::Yellow);
            pauseText.setPosition(sf::Vector2f(WINDOW_WIDTH / 2 - 80.f, WINDOW_HEIGHT / 2 - 60.f));
            resumeText.setFillColor(sf::Color::White);
            resumeText.setPosition(sf::Vector2f(WINDOW_WIDTH / 2 - 130.f, WINDOW_HEIGHT / 2));

            window.draw(pauseText);
            window.draw(resumeText);
        }

        window.display();
    }

    return 0;
}